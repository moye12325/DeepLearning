# 2.4 综合案例实战 - 股票数据读取与K线图绘制
# 2.4.1 初步尝试 - 股票数据读取与可视化

# 老版tushare不太好用了，可以参考如下帖子使用新版Tushare：
# https://shimo.im/docs/PGWdY6Q8xDKpvDXG/ 《Tushare Pro使用教程（一）》，可复制链接后用石墨文档 App 或小程序打开

